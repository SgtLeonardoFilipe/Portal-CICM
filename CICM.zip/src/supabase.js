import { createClient } from '@supabase/supabase-js';
const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY;
export const configured = !!(url && key && !url.includes('SEU-PROJETO'));
export const supabase = configured ? createClient(url, key, {
  auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false }
}) : null;
export const BUCKET = 'cicm_publico';
export const TIPOS = ['pdf','doc','docx','xls','xlsx','ppt','pptx','txt','jpg','jpeg','png'];
export const LIMITE = 15 * 1024 * 1024;
export function validarArquivo(file) {
  if (!file) throw new Error('Selecione um arquivo.');
  if (file.size === 0 || file.size > LIMITE) throw new Error('Arquivo vazio ou maior que 15 MB.');
  const ext = file.name.split('.').pop()?.toLowerCase();
  if (!TIPOS.includes(ext)) throw new Error('Formato não permitido. Use PDF, Word, Excel, PowerPoint, TXT ou imagem.');
  return ext;
}
export function falha(error) { if (error) throw error; }
export async function enviarArquivo(file, tipo) {
  const ext = validarArquivo(file);
  const caminho = `${tipo}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(BUCKET).upload(caminho, file, {
    upsert: false, contentType: file.type || 'application/octet-stream', cacheControl: '3600'
  });
  falha(error);
  return caminho;
}
export async function baixarArquivo(caminho, nome) {
  const {data,error} = await supabase.storage.from(BUCKET).download(caminho);
  falha(error);
  const u = URL.createObjectURL(data);
  const a = document.createElement('a'); a.href = u; a.download = nome || 'documento';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(u), 60000);
}
