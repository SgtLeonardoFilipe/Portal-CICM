import React, {useEffect, useMemo, useState} from 'react';
import {Upload, Download, FolderOpen, Search, FileText, CheckCircle2, Clock3, RefreshCw, Mail, Send, X, ArrowLeft, Users, AlertTriangle} from 'lucide-react';
import {supabase, configured, falha, enviarArquivo, baixarArquivo, validarArquivo} from './supabase';
const CATEGORIAS = ['Dados cadastrais','Pedidos ao Judiciário','Relatórios','Outros documentos'];
const dataFormatada = s => s ? new Date(s).toLocaleString('pt-BR') : '';
const erroTexto = e => e?.message || 'Não foi possível completar a operação.';
const inicial = {nome:'',equipe:'',categoria:CATEGORIAS[0],titulo:'',arquivo:null};

export default function App() {
  const [pedidos,setPedidos] = useState([]);
  const [respostas,setRespostas] = useState([]);
  const [carregando,setCarregando] = useState(false);
  const [erro,setErro] = useState('');
  const [aviso,setAviso] = useState('');
  const [filtro,setFiltro] = useState('Todos');
  const [busca,setBusca] = useState('');
  const [form,setForm] = useState(inicial);
  const [enviando,setEnviando] = useState(false);
  const [respondendo,setRespondendo] = useState(null);
  const [nomeResp,setNomeResp] = useState('');
  const [arquivoResp,setArquivoResp] = useState(null);
  const [baixando,setBaixando] = useState('');
  const [aba,setAba] = useState('arquivos');

  async function carregar() {
    if (!configured) return;
    setCarregando(true); setErro('');
    try {
      const [p,r] = await Promise.all([
        supabase.from('cicm_portal_pedidos').select('*').order('criado_em',{ascending:false}),
        supabase.from('cicm_portal_respostas').select('*').order('criado_em',{ascending:true})
      ]);
      falha(p.error); falha(r.error);
      setPedidos(p.data || []); setRespostas(r.data || []);
    } catch(e) { setErro(erroTexto(e)); }
    finally { setCarregando(false); }
  }
  useEffect(() => { carregar(); },[]);
  const respostasPorPedido = useMemo(() => respostas.reduce((acc,r) => {
    (acc[r.pedido_id] ||= []).push(r); return acc;
  },{}), [respostas]);
  const lista = useMemo(() => pedidos.filter(p => (filtro==='Todos'||p.categoria===filtro) &&
    [p.nome,p.equipe,p.titulo,p.categoria].some(v=>String(v||'').toLocaleLowerCase('pt-BR').includes(busca.toLocaleLowerCase('pt-BR')))),[pedidos,busca,filtro]);
  const respondidos = pedidos.filter(p => respostasPorPedido[p.id]?.length).length;

  async function novoPedido(e) {
    e.preventDefault(); setErro(''); setAviso(''); setEnviando(true);
    try {
      if (!form.nome.trim() || !form.equipe.trim() || !form.titulo.trim()) throw new Error('Preencha nome, equipe e título.');
      validarArquivo(form.arquivo);
      const path = await enviarArquivo(form.arquivo, 'pedidos');
      const {error} = await supabase.from('cicm_portal_pedidos').insert({
        nome:form.nome.trim(), equipe:form.equipe.trim(), categoria:form.categoria,
        titulo:form.titulo.trim(), arquivo_path:path, arquivo_nome:form.arquivo.name
      });
      falha(error);
      setForm(inicial); setAba('arquivos'); setAviso('Documento enviado! Ele já está disponível para a turma.');
      await carregar();
    } catch(e) { setErro(erroTexto(e)); }
    finally {setEnviando(false);}
  }
  async function responder(e) {
    e.preventDefault(); setErro(''); setAviso(''); setEnviando(true);
    try {
      if (!nomeResp.trim()) throw new Error('Informe o nome de quem está disponibilizando a resposta.');
      validarArquivo(arquivoResp);
      const path = await enviarArquivo(arquivoResp, 'respostas');
      const {error} = await supabase.from('cicm_portal_respostas').insert({
        pedido_id:respondendo.id, nome:nomeResp.trim(), arquivo_path:path, arquivo_nome:arquivoResp.name
      });
      falha(error); setRespondendo(null); setNomeResp(''); setArquivoResp(null);
      setAviso('Resposta publicada! Todos os alunos já podem baixá-la.'); await carregar();
    } catch(e) { setErro(erroTexto(e)); }
    finally {setEnviando(false);}
  }
  async function baixar(id,path,nome) {
    setBaixando(id); setErro(''); try{await baixarArquivo(path,nome);}catch(e){setErro(erroTexto(e));}finally{setBaixando('');}
  }
  return <>
    <header className="topbar"><div className="header-inner">
      <img className="brasao" src="/brasao-cicm.jpg" alt="Brasão do Curso de Investigação Criminal Militar"/>
      <div><div className="eyebrow">CURSO DE INVESTIGAÇÃO CRIMINAL MILITAR</div><h1>Portal CICM</h1><p>Central de pedidos, relatórios e respostas</p></div>
    </div></header>
    <main className="container">
      <div className="welcome"><div><h2>Arquivos do curso</h2><p>Envie um documento ou consulte os arquivos compartilhados com a turma.</p></div><div className="controls"><button className="light" onClick={carregar} disabled={carregando}><RefreshCw size={16}/>{carregando?'Atualizando':'Atualizar'}</button><button className="primary" onClick={()=>{setAba('enviar');setErro('')}}><Upload size={17}/> Enviar arquivo</button></div></div>
      <div className="stats"><div><strong>{pedidos.length}</strong><span>Pedidos e relatórios</span></div><div><strong>{respondidos}</strong><span>Com resposta</span></div><div><strong>{pedidos.length-respondidos}</strong><span>Aguardando resposta</span></div></div>
      {!configured && <div className="alert warning"><AlertTriangle size={18}/> Configure VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY no arquivo .env e reinicie o Vite.</div>}
      {erro && <div className="alert error" role="alert"><AlertTriangle size={18}/>{erro}<button className="close" onClick={()=>setErro('')} aria-label="Fechar erro"><X size={16}/></button></div>}
      {aviso && <div className="alert success" role="status"><CheckCircle2 size={18}/>{aviso}<button className="close" onClick={()=>setAviso('')} aria-label="Fechar aviso"><X size={16}/></button></div>}
      <div className="tabs"><button className={aba==='arquivos'?'selected':''} onClick={()=>setAba('arquivos')}><FolderOpen size={17}/> Todos os arquivos</button><button className={aba==='enviar'?'selected':''} onClick={()=>setAba('enviar')}><Upload size={17}/> Novo envio</button></div>
      {aba==='enviar' ? <section className="panel"><div className="panel-title"><h3>Enviar pedido ou relatório</h3><p>O arquivo ficará visível para todos os visitantes do portal.</p></div>
        <form className="form" onSubmit={novoPedido}><div className="cols"><label>Nome do aluno ou responsável<input maxLength="120" value={form.nome} onChange={e=>setForm({...form,nome:e.target.value})} required placeholder="Nome completo"/></label><label>Equipe<input maxLength="100" value={form.equipe} onChange={e=>setForm({...form,equipe:e.target.value})} required placeholder="Ex.: Equipe Alfa"/></label></div>
          <label>Categoria<select value={form.categoria} onChange={e=>setForm({...form,categoria:e.target.value})}>{CATEGORIAS.map(c=><option key={c}>{c}</option>)}</select></label>
          <label>Título do documento<input maxLength="180" value={form.titulo} onChange={e=>setForm({...form,titulo:e.target.value})} required placeholder="Ex.: Pedido nº 001 – Dados cadastrais"/></label>
          <label>Arquivo (até 15 MB)<input type="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.jpg,.jpeg,.png" onChange={e=>setForm({...form,arquivo:e.target.files?.[0]||null})} required/></label>
          <div className="actions"><button type="button" className="light" onClick={()=>setAba('arquivos')}><ArrowLeft size={16}/> Voltar</button><button className="primary" disabled={enviando||!configured} type="submit"><Send size={16}/>{enviando?'Enviando...':'Publicar documento'}</button></div>
        </form></section> : <>
          <div className="filters"><div className="search"><Search size={19}/><input aria-label="Pesquisar arquivos" value={busca} onChange={e=>setBusca(e.target.value)} placeholder="Buscar por pedido, aluno ou equipe..."/></div><select aria-label="Filtrar categoria" value={filtro} onChange={e=>setFiltro(e.target.value)}><option>Todos</option>{CATEGORIAS.map(c=><option key={c}>{c}</option>)}</select></div>
          {lista.length===0 ? <div className="empty"><FolderOpen size={35}/><h3>{carregando?'Carregando arquivos...':'Nenhum documento encontrado'}</h3><p>Quando alguém enviar um arquivo, ele aparecerá aqui.</p></div> : <div className="items">{lista.map(p=>{
            const r = respostasPorPedido[p.id]||[];
            return <article className="item" key={p.id}><div className="item-head"><span className="category">{p.categoria}</span><span className={'status '+(r.length?'done':'pending')}>{r.length?<><CheckCircle2 size={14}/> Respondido</>:<><Clock3 size={14}/> Aguardando resposta</>}</span></div>
              <h3>{p.titulo}</h3><div className="meta"><span><Users size={14}/>{p.equipe}</span><span>Enviado por {p.nome}</span><span>{dataFormatada(p.criado_em)}</span></div>
              <div className="attachment"><FileText size={19}/><span title={p.arquivo_nome}>{p.arquivo_nome}</span><button onClick={()=>baixar(p.id,p.arquivo_path,p.arquivo_nome)} disabled={baixando===p.id}><Download size={16}/> Baixar pedido</button></div>
              {r.length>0 && <div className="replies"><h4>Respostas disponíveis ({r.length})</h4>{r.map(a=><div className="reply" key={a.id}><div><CheckCircle2 size={17}/><span title={a.arquivo_nome}>{a.arquivo_nome}</span><small>por {a.nome} · {dataFormatada(a.criado_em)}</small></div><button onClick={()=>baixar(a.id,a.arquivo_path,a.arquivo_nome)} disabled={baixando===a.id}><Download size={16}/> Baixar</button></div>)}</div>}
              <div className="item-footer"><button className="outline" onClick={()=>{setRespondendo(p);setErro('')}}><Upload size={16}/> Anexar resposta</button></div>
            </article>;
          })}</div>}
        </>}
      <footer><Mail size={16}/> Aviso ao instrutor por e-mail configurável via Supabase. <span>Use apenas arquivos fictícios ou autorizados para compartilhamento público.</span></footer>
    </main>
    {respondendo && <div className="modal-backdrop" onClick={()=>{if(!enviando)setRespondendo(null)}}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="titulo-resposta" onClick={e=>e.stopPropagation()}><div className="modal-top"><h3 id="titulo-resposta">Anexar resposta</h3><button className="icon-btn" onClick={()=>setRespondendo(null)} disabled={enviando} aria-label="Fechar"><X size={20}/></button></div><p>Documento: <strong>{respondendo.titulo}</strong></p><div className="alert warning"><AlertTriangle size={17}/> Sem login, qualquer visitante pode publicar uma resposta. A autoria informada não é verificada.</div><form onSubmit={responder} className="form"><label>Nome de quem está respondendo<input value={nomeResp} maxLength="120" onChange={e=>setNomeResp(e.target.value)} required placeholder="Nome do instrutor"/></label><label>Arquivo da resposta (até 15 MB)<input type="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.jpg,.jpeg,.png" onChange={e=>setArquivoResp(e.target.files?.[0]||null)} required/></label><div className="actions"><button type="button" className="light" onClick={()=>setRespondendo(null)}>Cancelar</button><button className="primary" disabled={enviando||!configured}><Upload size={16}/>{enviando?'Publicando...':'Publicar resposta'}</button></div></form></section></div>}
  </>;
}
