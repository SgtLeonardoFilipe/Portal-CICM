# Portal CICM — Central de Arquivos (sem login)

Portal em React + Vite + Supabase. Qualquer visitante pode enviar pedido/relatório, visualizar, baixar ou anexar respostas. Cada resposta fica ligada ao pedido por `pedido_id`. Os arquivos e respostas ficam públicos para toda a turma.

## Instalação no Windows

1. Extraia o ZIP. No Supabase já existente, abra **SQL Editor** e rode `supabase/schema.sql`. Ele cria **novas** tabelas (`cicm_portal_pedidos`, `cicm_portal_respostas`) e um novo bucket (`cicm_publico`), sem apagar a estrutura antiga.
2. Copie `.env.example` para `.env`. Preencha `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` com a URL e chave pública do projeto (Project Settings -> API Keys). NUNCA use `service_role` ou `secret` no frontend.
3. No terminal na pasta do projeto:
   ```powershell
   npm install
   npm run dev
   ```
4. Abra o endereço indicado no terminal, geralmente `http://localhost:5173`.

### Como usar

- **Novo envio:** aluno informa nome, equipe, categoria, título e arquivo e publica.
- **Todos os arquivos:** qualquer pessoa pesquisa e baixa os documentos.
- **Anexar resposta:** qualquer pessoa pode anexar uma ou mais respostas a um pedido (sem login, não é possível identificar o instrutor de forma confiável).
- São aceitos arquivos de até **15 MB**: PDF, Word, Excel, PowerPoint, TXT e JPG/PNG.
- A estrutura **não permite atualizar nem apagar** registros/arquivos pela interface pública. Um administrador do Supabase pode executar manutenção no painel. Se o upload for concluído mas o cadastro do pedido falhar, o arquivo fica órfão e deve ser removido manualmente.

## Aviso automático por e-mail (etapa opcional, requer configuração)

A inclusão de um pedido **não envia e-mails automaticamente até esta integração ser ativada**. Configuração sugerida: Edge Function + Database Webhook + Resend.

1. Crie uma conta no Resend, valide um domínio remetente e obtenha a chave da API.
2. Instale o Supabase CLI e autentique-se no seu projeto. No diretório do portal:
   ```powershell
   npx supabase login
   npx supabase link --project-ref SEU_PROJECT_REF
   npx supabase secrets set RESEND_API_KEY=re_xxx INSTRUTOR_EMAIL=instrutor@dominio.com REMETENTE_EMAIL="CICM <avisos@seudominio.com>" WEBHOOK_SECRET=SEGREDO_ALEATORIO_FORTE PORTAL_URL=https://endereco-do-portal
   npx supabase functions deploy avisar-instrutor --no-verify-jwt
   ```
   O `WEBHOOK_SECRET` é exclusivo da comunicação interna entre o webhook e a função, **não** é senha de aluno/instrutor. Nunca o coloque em `.env` do Vite.
3. No Supabase, acesse **Database -> Webhooks -> Create a new hook**:
   - Tabela: `public.cicm_portal_pedidos`
   - Evento: `INSERT`
   - Método: `POST`
   - URL: `https://SEU_PROJECT_REF.supabase.co/functions/v1/avisar-instrutor`
   - HTTP header: `x-webhook-secret: SEGREDO_ALEATORIO_FORTE` (o mesmo salvo na Edge Function)
4. Faça um envio de teste, confira os logs da Edge Function e a caixa de entrada. A notificação inclui apenas metadados, sem anexos.

Se o painel do Supabase não permitir headers personalizados no Webhook, use o recurso `pg_net` com secrets armazenados no Vault ou um intermediário protegido. Não exponha a chave da função no código da página. As notificações são enviadas em modo melhor esforço e não impedem que o pedido apareça no portal caso a entrega do e-mail falhe.

## Segurança e limites importantes

- **Portal 100% público:** quem conhecer a URL pode ler, baixar e publicar pedidos e respostas, inclusive fingindo ser um instrutor. A ausência de login significa que NÃO há verificação de autoria. A ferramenta **não deve hospedar dados reais de investigações, documentos sigilosos, dados cadastrais sensíveis ou informações pessoais de terceiros**. Use apenas material fictício ou autorizado para divulgação irrestrita.
- Não são permitidas atualizações e exclusões pela API pública, mas **qualquer pessoa pode fazer novos uploads** e consumir armazenamento. Para produção, acrescentar CAPTCHA, proteção anti-spam, limites de taxa por IP e moderação por backend. O `max_file_size` e os MIME types são definidos no bucket. Validação por extensão e MIME não equivale a antivírus; escaneie arquivos se houver usuários não confiáveis.
- O usuário não precisa ter conta Supabase Auth. As permissões de leitura/inserção são fornecidas ao papel `anon` pelas políticas RLS do script.
- O bucket é publicamente acessível e os arquivos devem ser tratados como publicados na internet.
- O envio de e-mail requer uma configuração externa de remetente e credenciais. Não é possível garantir que o e-mail chegue (anti-spam, validação do domínio e limites do provedor).

## Arquivos

- `src/App.jsx`: tela única.
- `src/supabase.js`: leitura, upload e download.
- `supabase/schema.sql`: tabelas, políticas e storage.
- `supabase/functions/avisar-instrutor/index.ts`: notificação por e-mail.
- `public/brasao-cicm.jpg`: brasão do curso.
